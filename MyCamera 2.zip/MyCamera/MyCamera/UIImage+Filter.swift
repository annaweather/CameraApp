//
//  UIImage+Filter.swift
//  MyCamera
//
//  Created by Anna Ueda on 2023-11-17.
//

import Foundation
import UIKit

extension UIImage {
    func applyFilte(filterName: String) -> UIImage? {
        
        //        selectedFilter = filterName
        
        //        filterSelectNumber += 1
        //        if filterSelectNumber == filterArray.count {
        //            filterSelectNumber = 0
        //        }
        
        let rotate = self.imageOrientation
        let inputImage = CIImage(image: self)
        
        guard let effectFilter = CIFilter(name: filterName) else {
            return nil
        }
        
        effectFilter.setDefaults()
        effectFilter.setValue(inputImage, forKey: kCIInputImageKey)
        guard let outputImage = effectFilter.outputImage else {
            return nil
        }
        let ciContext = CIContext(options: nil)
        guard let cgImage = ciContext.createCGImage(outputImage, from: outputImage.extent) else {
            return nil
            
        }
        return UIImage(
            cgImage: cgImage,
            scale: 1.0,
            orientation: rotate
        )
    }
}
