//
//  EditView.swift
//  MyCamera
//
//  Created by Anna Ueda on 2023-11-12.
//

import SwiftUI

struct EditView: View {
 //   @Binding var isShowSheet: Bool
//    let captureImage: UIImage
    @State var showImage: UIImage?
    @State var selectedFilter: String?
    @State var filterSelectNumber = 0
    @Binding var viewModel: EditViewModel
    
    let filterArray = ["CIPhotoEffectMono",
                       "CIPhotoEffectChrome",
                       "CIPhotoEffectFade",
                       "CIPhotoEffectInstant",
                       "CIPhotoEffectNoir",
                       "CIPhotoEffectProcess",
                       "CIPhotoEffectTonal",
                       "CIPhotoEffectTransfer",
                       "CISepiaToncoe"
    ]
    

    
    var body: some View {
        VStack {
            Spacer()
            
            if let showImage {
                Image(uiImage: showImage)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(15)
            }
            
            Text(selectedFilter ?? "No effect selected")

//            if let selectedFilter = selectedFilter {
//            Text("\(selectedFilter)").frame(height: 30)
//        } else {
//            Spacer().frame(height: 30)
//        }
            
            Button {
                
                let filterName = filterArray[filterSelectNumber]
                
                selectedFilter = filterName
                
                filterSelectNumber += 1
                if filterSelectNumber == filterArray.count {
                    filterSelectNumber = 0
                }
                
                viewModel.applyFilter(filterName: selectedFilter!)
                
                
//                let rotate = captureImage.imageOrientation
//                let inputImage = CIImage(image: captureImage)
//                
//                guard let effectFilter = CIFilter(name: filterName) else {
//                    return
//                }
//                effectFilter.setDefaults()
//                effectFilter.setValue(inputImage, forKey: kCIInputImageKey)
//                guard let outputImage = effectFilter.outputImage else {
//                    return
//                }
//                let ciContext = CIContext(options: nil)
//                guard let cgImage = ciContext.createCGImage(outputImage, from: outputImage.extent) else {
//                    return
//                }
//                showImage = UIImage(
//                    cgImage: cgImage,
//                    scale: 1.0,
//                    orientation: rotate
//                )
            } label: {
                Text("Change your filter")
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .multilineTextAlignment(.center)
                    .background(Color.mint)
                    .foregroundStyle(Color.white)
                    .font(.headline)
                    .cornerRadius(50)
            }
            .padding()

            
            if let showImage = showImage?.resized() {
                let shareImage = Image(uiImage: showImage)
                ShareLink(item: shareImage, subject: nil, message: nil,
                          preview: SharePreview("Photo", image: shareImage)) {
                    Text("Share")
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .multilineTextAlignment(.center)
                        .background(Color.mint)
                        .foregroundStyle(Color.white)
                        .font(.headline)
                        .cornerRadius(50)
                }
                          .padding()
            }
            Button {
                viewModel.isShowSheet.toggle()
            } label: {
                Text("Close")
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .multilineTextAlignment(.center)
                    .background(Color.mint)
                    .foregroundStyle(Color.white)
                    .font(.headline)
                    .cornerRadius(50)
                
            }
            .padding()
        }
//        .task {
//
//        }
        .onAppear {
            showImage = viewModel.captureImage
        }
    }
}

#Preview {
    EditView(
        viewModel: .constant(EditViewModel())
    )
}

