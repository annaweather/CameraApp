//
//  MyCameraApp.swift
//  MyCamera
//
//  Created by Anna Ueda on 2023-11-12.
//

import SwiftUI

@main
struct MyCameraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
