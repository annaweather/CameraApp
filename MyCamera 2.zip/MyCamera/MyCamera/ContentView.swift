//
//  ContentView.swift
//  MyCamera
//
//  Created by Anna Ueda on 2023-11-12.
//

import SwiftUI
import PhotosUI

struct ContentView: View {
    
//    @State var captureImage: UIImage? = nil
//    @State var isShowSheet = false
//    @State var photoPickerSelectedImage: PhotosPickerItem? = nil
//
    
    @State private var viewModel = EditViewModel()
    
    var body: some View {
        HStack {
            
            Spacer()
            
            Button {
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    print("Camera is activated")
                    viewModel.captureImage = nil
                    viewModel.isShowSheet.toggle()
                } else {
                    print("Camera is innactivated")
                }
            } label: {
                VStack {
                    Image(systemName: "suit.heart.fill")
                        .font(.system(size: 50))
                        .foregroundStyle(LinearGradient(colors: [.indigo, .pink], startPoint: .bottom, endPoint: .top))
                    
                    Text("Camera")
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .multilineTextAlignment(.center)
                        .background(.clear)
                        .foregroundStyle(Color.primary)
                        .cornerRadius(20)
                        .padding()
                }
            }
            .padding()
            .sheet(isPresented: $viewModel.isShowSheet) {
                if viewModel.captureImage != nil {
                    EditView(viewModel: $viewModel)
                } else {
                    ImagePickerView(isShowSheet: $viewModel.isShowSheet, captureImage: $viewModel.captureImage)
                }
            }
            
            PhotosPicker(selection: $viewModel.photoPickerSelectedImage, matching: .images, preferredItemEncoding: .automatic, photoLibrary: .shared()) {
                
                VStack {
                    Image(systemName: "circle.bottomrighthalf.checkered")
                        .font(.system(size: 50))
                        .foregroundStyle(LinearGradient(colors: [.indigo, .mint], startPoint: .bottom, endPoint: .top))
                    
                    Text("Edit")
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .multilineTextAlignment(.center)
                        .background(.clear)
                        .foregroundStyle(Color.primary)
                        .cornerRadius(20)
                        .padding()
                }
            }
            .padding()
            // take out selected photo
            .onChange(of: viewModel.photoPickerSelectedImage, initial: true, { oldValue, newValue in
                if let newValue {
                    newValue.loadTransferable(type: Data.self) { result in
                        switch result {
                        case .success(let data):
                            if let data {
                                viewModel.captureImage = UIImage(data: data)
                            }
                        case .failure:
                            return
                        }
                    }
                }
            })
        }
        .onChange(of: viewModel.captureImage, initial: true, { oldValue, newValue in
            if let _ = newValue {
                viewModel.isShowSheet.toggle()
            }
        })
    }
}

#Preview {
    ContentView()
}

