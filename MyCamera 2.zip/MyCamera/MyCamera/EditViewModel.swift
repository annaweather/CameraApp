//
//  EditViewModel.swift
//  MyCamera
//
//  Created by Anna Ueda on 2023-11-17.
//

import Foundation
import UIKit
import PhotosUI
import _PhotosUI_SwiftUI

@Observable
class EditViewModel {
    var captureImage: UIImage?
    var isShowSheet = false
    var photoPickerSelectedImage: PhotosPickerItem?
    
    
    func applyFilter(filterName: String) {
        
        if let image = captureImage  {
            if let captureImage = image.applyFilte(filterName: filterName) {
                self.captureImage = captureImage
            }
        }
        
        
    }
}
